//*********************************************************************\
// File name        : c4d_symbols.h
// Description      : symbol definition file for the plugin 
// Created at       : 
// Created by       : Resource editor
// Modified by      : 
//*********************************************************************/
// WARNING : Only edit this file, if you exactly know what you are doing.
// WARNING : The comments are important, too.

enum
{
  _FIRST_ELEMENT_      = 10000,
  // Dialog definitions of IDD_DIALOG1 start here
  IDD_DIALOG1,
  IDC_USER1,
  MainGroup,
  MainGroup1,
  IDC_BUTTON1,
  IDC_CHECK22,
  IDC_CHECK1,
  IDC_CHECK5,
  IDC_CHECK4,
  IDC_CHECK2,
  IDC_CHECK3,
  IDC_CHECK10,
  IDC_CHECK6,
  IDC_CHECK21,
  IDC_CHECK23,
  MainGroup2,
  IDC_G,
  IDC_G1,
  IDC_CHECK12,
  IDC_CHECK13,
  IDC_G2,
  IDC_CHECK14,
  IDC_BUTTON2,
  IDC_EDIT2,
  IDC_COMBO1,
  IDC_COMBO2,
  IDC_COMBO3,
  IDC_COMBO4,
  IDC_COMBO5,
  IDC_COMBO6,
  IDC_COMBO8,
  IDC_EDIT1,
  IDC_CHECK8,
  // Dialog definitions of IDD_DIALOG1 end here


// End of symbol definition
  _DUMMY_ELEMENT_
};
